<main <?php echo e($attributes->class(['layout-content']), false); ?>>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/components/layout/content.blade.php ENDPATH**/ ?>