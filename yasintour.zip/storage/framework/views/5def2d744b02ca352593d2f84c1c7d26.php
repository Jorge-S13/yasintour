<?php if (isset($component)) { $__componentOriginal73c6f62b756759d0cfcff0c734cdf46b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73c6f62b756759d0cfcff0c734cdf46b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'moonshine::components.form.select','data' => ['attributes' => $element->attributes()->merge([
        'id' => $element->id(),
        'name' => $element->name(),
    ]),'nullable' => $element->isNullable(),'searchable' => $element->isSearchable(),'asyncRoute' => $element->asyncUrl(),'class' => \Illuminate\Support\Arr::toCssClasses(['form-invalid' => formErrors($errors ?? false, $element->getFormName())->has($element->name())])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('moonshine::form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->attributes()->merge([
        'id' => $element->id(),
        'name' => $element->name(),
    ])),'nullable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->isNullable()),'searchable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->isSearchable()),'asyncRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($element->asyncUrl()),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses(['form-invalid' => formErrors($errors ?? false, $element->getFormName())->has($element->name())]))]); ?>
     <?php $__env->slot('options', null, []); ?> 
        <?php if($element->isNullable()): ?>
            <option value=""><?php echo e($element->attributes()->get('placeholder', '-'), false); ?></option>
        <?php endif; ?>
        <?php $__currentLoopData = $element->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_array($optionName)): ?>
                <optgroup label="<?php echo e($optionValue, false); ?>">
                    <?php $__currentLoopData = $optionName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oValue => $oName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($element->isSelected($oValue)): echo 'selected'; endif; ?>
                                value="<?php echo e($oValue, false); ?>"
                                data-custom-properties='<?php echo json_encode($element->getOptionProperties($oValue), 15, 512) ?>'
                        >
                            <?php echo e($oName, false); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </optgroup>
            <?php else: ?>
                <option <?php if($element->isSelected($optionValue)): echo 'selected'; endif; ?>
                        value="<?php echo e($optionValue, false); ?>"
                        data-custom-properties='<?php echo json_encode($element->getOptionProperties($optionValue), 15, 512) ?>'
                >
                    <?php echo e($optionName, false); ?>

                </option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73c6f62b756759d0cfcff0c734cdf46b)): ?>
<?php $attributes = $__attributesOriginal73c6f62b756759d0cfcff0c734cdf46b; ?>
<?php unset($__attributesOriginal73c6f62b756759d0cfcff0c734cdf46b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73c6f62b756759d0cfcff0c734cdf46b)): ?>
<?php $component = $__componentOriginal73c6f62b756759d0cfcff0c734cdf46b; ?>
<?php unset($__componentOriginal73c6f62b756759d0cfcff0c734cdf46b); ?>
<?php endif; ?>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/fields/select.blade.php ENDPATH**/ ?>