<div <?php echo e($attributes
        ->class([
            'my-4',
        ]), false); ?>></div>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/decorations/line-break.blade.php ENDPATH**/ ?>