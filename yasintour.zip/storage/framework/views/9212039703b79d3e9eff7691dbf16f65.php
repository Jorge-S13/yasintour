<?php ($settings = \App\Models\Settings::find(1)); ?>
<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h4 class="text-white mb-3">Yasin avia travel</h4>
                <a class="btn btn-link" href="<?php echo e(route('about'), false); ?>">О нас</a>
                <a class="btn btn-link" href="<?php echo e(route('contact'), false); ?>">Контакты</a>
                <a class="btn btn-link" href="">Информация</a>
                <a class="btn btn-link" href="">Вопросы и помощь</a>
            </div>
            <div class="col-lg-3 col-md-6">
                <h4 class="text-white mb-3">Контакты</h4>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i><a href="https://www.google.com/maps/place/41%C2%B018'13.6%22N+69%C2%B017'19.8%22E/@41.303271,69.288873,15z/data=!4m4!3m3!8m2!3d41.3037778!4d69.2888333?hl=uz&entry=ttu" class="text-decoration-none text-reset"><?php echo e($settings->address, false); ?></a></p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i><a href="tel:<?php echo e($settings->phone_number, false); ?>" class="text-decoration-none text-reset"><?php echo e($settings->phone_number, false); ?></a></p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href="<?php echo e($settings->facebook_url, false); ?>"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href="<?php echo e($settings->telegram_url, false); ?>"><i class="fab fa-telegram"></i></a>
                    <a class="btn btn-outline-light btn-social" href="<?php echo e($settings->instagram_url, false); ?>"><i class="fab fa-instagram"></i></a>
                </div>
            </div>































        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">

            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
<?php /**PATH C:\OSPanel\domains\yasintour\resources\views/includes/footer.blade.php ENDPATH**/ ?>