<textarea <?php echo e($attributes->merge([
    'class' => 'form-textarea',
    ]), false); ?>

><?php echo e($slot, false); ?></textarea>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/components/form/textarea.blade.php ENDPATH**/ ?>