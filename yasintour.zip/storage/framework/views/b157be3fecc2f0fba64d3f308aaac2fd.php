<div <?php echo e($attributes
        ->class([
            'mb-4',
        ]), false); ?>>
    <?php echo e($element->label(), false); ?>

</div>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/decorations/heading.blade.php ENDPATH**/ ?>