<!-- Navbar & Hero Start -->
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="<?php echo e(route('home'), false); ?>" class="navbar-brand">
            <img src="<?php echo e(asset('img/yasinlogo.png'), false); ?>" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?php echo e(route('home'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('home') ? 'active' : '', false); ?>">Главная</a>
                <a href="<?php echo e(route('packages'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('packages') ? 'active' : '', false); ?>">Страны</a>
                <a href="<?php echo e(route('destination'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('destination') ? 'active' : '', false); ?>">Горящие Туры</a>
                <a href="<?php echo e(route('aviakassa'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('aviakassa') ? 'active' : '', false); ?>">Авиакасса</a>
                <a href="<?php echo e(route('services'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('services') ? 'active' : '', false); ?>">Наши услуги</a>
                
                
                
                
                
                
                
                
                
                
                <a href="<?php echo e(route('about'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('about') ? 'active' : '', false); ?>">О нас</a>
                <a href="<?php echo e(route('contact'), false); ?>" class="nav-item nav-link <?php echo e(Route::is('contact') ? 'active' : '', false); ?>">Контакты</a>
            </div>
        </div>
    </nav>

    <div class="container-fluid bg-primary py-5 mb-5 hero-header">
        <div class="container py-5">
            <div class="row justify-content-center py-5">
                <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Наслаждайтесь отдыхом с нами</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Navbar & Hero End -->
<?php /**PATH C:\OSPanel\domains\yasintour\resources\views/includes/navbar.blade.php ENDPATH**/ ?>