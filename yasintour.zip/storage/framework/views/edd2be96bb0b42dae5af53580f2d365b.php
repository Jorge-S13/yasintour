<button
    <?php echo e($attributes->class(['btn'])
        ->merge(['type' => 'button']), false); ?>

>
    <?php echo e($slot, false); ?>

</button>
<?php /**PATH C:\OSPanel\domains\yasintour\vendor\moonshine\moonshine\resources\views/components/form/button.blade.php ENDPATH**/ ?>